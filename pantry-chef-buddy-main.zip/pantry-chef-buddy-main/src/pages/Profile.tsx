import { User, Settings, Heart, BookOpen, Award, Clock } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";

const Profile = () => {
  const stats = [
    { label: "Recipes Saved", value: 24, icon: BookOpen, color: "text-primary" },
    { label: "Dishes Cooked", value: 12, icon: Award, color: "text-accent" },
    { label: "Time Saved", value: "5h", icon: Clock, color: "text-success" },
    { label: "Favorites", value: 18, icon: Heart, color: "text-destructive" },
  ];

  const preferences = [
    { name: "Vegetarian", active: false },
    { name: "Gluten-Free", active: true },
    { name: "Quick Meals", active: true },
    { name: "Spicy Food", active: false },
  ];

  return (
    <div className="min-h-screen pb-20 bg-gradient-warm">
      {/* Header */}
      <div className="gradient-hero text-white p-6 pb-12">
        <div className="max-w-md mx-auto text-center">
          <Avatar className="w-24 h-24 mx-auto mb-4 border-4 border-white shadow-lg">
            <AvatarImage src="https://api.dicebear.com/7.x/avataaars/svg?seed=user" />
            <AvatarFallback>JD</AvatarFallback>
          </Avatar>
          <h1 className="font-serif text-2xl font-bold mb-1">John Doe</h1>
          <p className="text-white/90">Home Cook Enthusiast</p>
        </div>
      </div>

      <div className="max-w-md mx-auto px-4 -mt-8">
        {/* Stats Grid */}
        <div className="grid grid-cols-2 gap-3 mb-6">
          {stats.map((stat) => (
            <Card key={stat.label} className="p-4 text-center shadow-soft">
              <stat.icon className={`h-8 w-8 mx-auto mb-2 ${stat.color}`} />
              <div className="text-2xl font-bold mb-1">{stat.value}</div>
              <div className="text-xs text-muted-foreground">{stat.label}</div>
            </Card>
          ))}
        </div>

        {/* Dietary Preferences */}
        <Card className="p-6 mb-4 shadow-soft">
          <h2 className="font-serif text-xl font-bold mb-4">Dietary Preferences</h2>
          <div className="flex flex-wrap gap-2">
            {preferences.map((pref) => (
              <Badge
                key={pref.name}
                variant={pref.active ? "default" : "secondary"}
                className="cursor-pointer"
              >
                {pref.name}
              </Badge>
            ))}
          </div>
        </Card>

        {/* Achievement Badges */}
        <Card className="p-6 mb-4 shadow-soft">
          <h2 className="font-serif text-xl font-bold mb-4">Achievements</h2>
          <div className="grid grid-cols-3 gap-4">
            <div className="text-center">
              <div className="w-16 h-16 mx-auto mb-2 bg-primary/10 rounded-full flex items-center justify-center">
                <Award className="h-8 w-8 text-primary" />
              </div>
              <div className="text-xs font-medium">First Recipe</div>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 mx-auto mb-2 bg-accent/10 rounded-full flex items-center justify-center">
                <Award className="h-8 w-8 text-accent" />
              </div>
              <div className="text-xs font-medium">10 Dishes</div>
            </div>
            <div className="text-center opacity-50">
              <div className="w-16 h-16 mx-auto mb-2 bg-muted rounded-full flex items-center justify-center">
                <Award className="h-8 w-8 text-muted-foreground" />
              </div>
              <div className="text-xs font-medium">Master Chef</div>
            </div>
          </div>
        </Card>

        {/* Settings */}
        <Card className="p-6 shadow-soft">
          <h2 className="font-serif text-xl font-bold mb-4">Settings</h2>
          <div className="space-y-3">
            <Button variant="ghost" className="w-full justify-start">
              <Settings className="h-5 w-5 mr-3" />
              App Settings
            </Button>
            <Button variant="ghost" className="w-full justify-start">
              <User className="h-5 w-5 mr-3" />
              Edit Profile
            </Button>
            <Button variant="ghost" className="w-full justify-start text-destructive hover:text-destructive">
              Sign Out
            </Button>
          </div>
        </Card>
      </div>
    </div>
  );
};

export default Profile;
