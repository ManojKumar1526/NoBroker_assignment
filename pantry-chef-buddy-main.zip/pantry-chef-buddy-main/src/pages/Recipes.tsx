import { useState } from "react";
import { Search, Grid, List, Plus, Filter, FolderOpen } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import RecipeCard from "@/components/RecipeCard";
import { useNavigate } from "react-router-dom";
import { Badge } from "@/components/ui/badge";

const Recipes = () => {
  const navigate = useNavigate();
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid");
  const [searchQuery, setSearchQuery] = useState("");

  const collections = [
    { name: "Quick Dinners", count: 12, color: "bg-primary" },
    { name: "Mom's Recipes", count: 8, color: "bg-accent" },
    { name: "Party Food", count: 15, color: "bg-success" },
  ];

  const recipes = [
    {
      id: "1",
      title: "Classic Pasta Carbonara",
      image: "https://images.unsplash.com/photo-1612874742237-6526221588e3?w=800&q=80",
      time: "25 min",
      servings: 4,
      difficulty: "Easy" as const,
      tags: ["Italian", "Pasta"],
    },
    {
      id: "2",
      title: "Thai Green Curry",
      image: "https://images.unsplash.com/photo-1455619452474-d2be8b1e70cd?w=800&q=80",
      time: "40 min",
      servings: 6,
      difficulty: "Medium" as const,
      tags: ["Thai", "Spicy"],
    },
    {
      id: "3",
      title: "Margherita Pizza",
      image: "https://images.unsplash.com/photo-1574071318508-1cdbab80d002?w=800&q=80",
      time: "30 min",
      servings: 4,
      difficulty: "Medium" as const,
      tags: ["Italian", "Pizza"],
    },
    {
      id: "4",
      title: "Caesar Salad",
      image: "https://images.unsplash.com/photo-1546793665-c74683f339c1?w=800&q=80",
      time: "15 min",
      servings: 2,
      difficulty: "Easy" as const,
      tags: ["Salad", "Quick"],
    },
    {
      id: "5",
      title: "Beef Tacos",
      image: "https://images.unsplash.com/photo-1551504734-5ee1c4a1479b?w=800&q=80",
      time: "35 min",
      servings: 6,
      difficulty: "Easy" as const,
      tags: ["Mexican", "Dinner"],
    },
    {
      id: "6",
      title: "Mushroom Risotto",
      image: "https://images.unsplash.com/photo-1476124369491-c49bd0e4f333?w=800&q=80",
      time: "45 min",
      servings: 4,
      difficulty: "Hard" as const,
      tags: ["Italian", "Comfort Food"],
    },
  ];

  return (
    <div className="min-h-screen pb-20 bg-gradient-warm">
      {/* Header */}
      <div className="gradient-hero text-white p-6 pb-8">
        <div className="max-w-md mx-auto">
          <h1 className="font-serif text-3xl font-bold mb-2">Recipe Library</h1>
          <p className="text-white/90">Your personal collection</p>
        </div>
      </div>

      <div className="max-w-md mx-auto px-4 -mt-4">
        {/* Search and Filter */}
        <Card className="p-4 mb-6 shadow-soft">
          <div className="flex gap-2 mb-3">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search recipes..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-9"
              />
            </div>
            <Button variant="outline" size="icon">
              <Filter className="h-4 w-4" />
            </Button>
          </div>
          <div className="flex gap-2">
            <Button
              variant={viewMode === "grid" ? "default" : "outline"}
              size="sm"
              onClick={() => setViewMode("grid")}
            >
              <Grid className="h-4 w-4 mr-1" />
              Grid
            </Button>
            <Button
              variant={viewMode === "list" ? "default" : "outline"}
              size="sm"
              onClick={() => setViewMode("list")}
            >
              <List className="h-4 w-4 mr-1" />
              List
            </Button>
          </div>
        </Card>

        {/* Collections */}
        <div className="mb-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-serif text-xl font-bold">Collections</h2>
            <Button variant="ghost" size="sm">
              <Plus className="h-4 w-4 mr-1" />
              New
            </Button>
          </div>
          <div className="grid grid-cols-2 gap-3">
            {collections.map((collection) => (
              <Card
                key={collection.name}
                className="p-4 cursor-pointer hover:shadow-md transition-all"
              >
                <div className={`${collection.color} w-12 h-12 rounded-xl flex items-center justify-center mb-3`}>
                  <FolderOpen className="h-6 w-6 text-white" />
                </div>
                <div className="font-semibold text-sm mb-1">{collection.name}</div>
                <div className="text-xs text-muted-foreground">{collection.count} recipes</div>
              </Card>
            ))}
          </div>
        </div>

        {/* All Recipes */}
        <div className="mb-6">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="font-serif text-xl font-bold">All Recipes</h2>
              <p className="text-sm text-muted-foreground">{recipes.length} recipes</p>
            </div>
            <Button variant="outline" size="sm" className="border-primary text-primary">
              <Plus className="h-4 w-4 mr-1" />
              Import
            </Button>
          </div>

          {/* Popular Tags */}
          <div className="flex flex-wrap gap-2 mb-4">
            {["All", "Italian", "Quick", "Vegetarian", "Spicy"].map((tag) => (
              <Badge
                key={tag}
                variant={tag === "All" ? "default" : "secondary"}
                className="cursor-pointer"
              >
                {tag}
              </Badge>
            ))}
          </div>

          <div className={viewMode === "grid" ? "space-y-4" : "space-y-3"}>
            {recipes.map((recipe) => (
              <RecipeCard
                key={recipe.id}
                {...recipe}
                onClick={() => navigate(`/recipe/${recipe.id}`)}
              />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Recipes;
