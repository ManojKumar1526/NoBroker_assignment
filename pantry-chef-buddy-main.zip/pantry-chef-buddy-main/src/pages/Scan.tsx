import { useState } from "react";
import { Camera, Plus, Sparkles, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import RecipeCard from "@/components/RecipeCard";
import { useNavigate } from "react-router-dom";

const Scan = () => {
  const navigate = useNavigate();
  const [ingredients, setIngredients] = useState([
    "Tomatoes",
    "Pasta",
    "Garlic",
    "Olive Oil",
    "Basil",
  ]);
  const [newIngredient, setNewIngredient] = useState("");
  const [showCamera, setShowCamera] = useState(false);

  const handleAddIngredient = () => {
    if (newIngredient.trim()) {
      setIngredients([...ingredients, newIngredient.trim()]);
      setNewIngredient("");
    }
  };

  const handleRemoveIngredient = (index: number) => {
    setIngredients(ingredients.filter((_, i) => i !== index));
  };

  const suggestedRecipes = [
    {
      id: "1",
      title: "Classic Pasta Carbonara",
      image: "https://images.unsplash.com/photo-1612874742237-6526221588e3?w=800&q=80",
      time: "25 min",
      servings: 4,
      difficulty: "Easy" as const,
      tags: ["Italian", "Pasta"],
      matchPercentage: 85,
    },
    {
      id: "2",
      title: "Tomato Basil Bruschetta",
      image: "https://images.unsplash.com/photo-1572695157366-5e585ab2b69f?w=800&q=80",
      time: "15 min",
      servings: 6,
      difficulty: "Easy" as const,
      tags: ["Italian", "Appetizer"],
      matchPercentage: 95,
    },
    {
      id: "3",
      title: "Garlic Herb Pasta",
      image: "https://images.unsplash.com/photo-1621996346565-e3dbc646d9a9?w=800&q=80",
      time: "20 min",
      servings: 4,
      difficulty: "Easy" as const,
      tags: ["Quick", "Italian"],
      matchPercentage: 78,
    },
  ];

  return (
    <div className="min-h-screen pb-20 bg-gradient-warm">
      {/* Header */}
      <div className="gradient-hero text-white p-6 pb-8">
        <div className="max-w-md mx-auto">
          <h1 className="font-serif text-3xl font-bold mb-2">Ingredient Scanner</h1>
          <p className="text-white/90">Scan or add ingredients to discover recipes</p>
        </div>
      </div>

      <div className="max-w-md mx-auto px-4 -mt-4">
        {/* Camera Scan Card */}
        <Card className="p-6 mb-6 shadow-soft">
          {!showCamera ? (
            <Button
              variant="outline"
              className="w-full h-48 border-dashed border-2 hover:border-primary hover:bg-primary/5"
              onClick={() => setShowCamera(true)}
            >
              <div className="text-center">
                <Camera className="h-12 w-12 mx-auto mb-3 text-primary" />
                <div className="font-semibold text-lg mb-1">Scan Your Ingredients</div>
                <div className="text-sm text-muted-foreground">
                  Point your camera at your fridge or pantry
                </div>
              </div>
            </Button>
          ) : (
            <div className="relative">
              <div className="bg-muted rounded-lg h-48 flex items-center justify-center">
                <div className="text-center">
                  <Camera className="h-12 w-12 mx-auto mb-3 text-primary animate-pulse" />
                  <div className="font-semibold">Camera Active</div>
                  <div className="text-sm text-muted-foreground">AI scanning in progress...</div>
                </div>
              </div>
              <Button
                size="sm"
                variant="destructive"
                className="absolute top-2 right-2"
                onClick={() => setShowCamera(false)}
              >
                Close
              </Button>
            </div>
          )}
        </Card>

        {/* Manual Add */}
        <Card className="p-4 mb-6 shadow-soft">
          <div className="flex gap-2">
            <Input
              placeholder="Add ingredient manually..."
              value={newIngredient}
              onChange={(e) => setNewIngredient(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleAddIngredient()}
              className="flex-1"
            />
            <Button onClick={handleAddIngredient} className="bg-primary">
              <Plus className="h-5 w-5" />
            </Button>
          </div>
        </Card>

        {/* Ingredients List */}
        <Card className="p-4 mb-6 shadow-soft">
          <div className="flex items-center gap-2 mb-4">
            <h3 className="font-semibold text-lg">Your Ingredients</h3>
            <Badge variant="secondary">{ingredients.length}</Badge>
          </div>
          <div className="flex flex-wrap gap-2">
            {ingredients.map((ingredient, index) => (
              <Badge
                key={index}
                variant="secondary"
                className="text-sm py-2 px-3 pr-1"
              >
                {ingredient}
                <button
                  onClick={() => handleRemoveIngredient(index)}
                  className="ml-2 hover:text-destructive"
                >
                  <X className="h-3 w-3" />
                </button>
              </Badge>
            ))}
          </div>
        </Card>

        {/* AI Suggestions */}
        <div className="mb-6">
          <div className="flex items-center gap-2 mb-4">
            <Sparkles className="h-5 w-5 text-accent" />
            <h2 className="font-serif text-2xl font-bold">What You Can Make</h2>
          </div>
          <p className="text-muted-foreground mb-4">
            Recipes sorted by ingredient match
          </p>
          <div className="space-y-4">
            {suggestedRecipes.map((recipe) => (
              <RecipeCard
                key={recipe.id}
                {...recipe}
                onClick={() => navigate(`/recipe/${recipe.id}`)}
              />
            ))}
          </div>
        </div>

        {/* Need More Ingredients */}
        <Card className="p-4 bg-accent/5 border-accent/20">
          <div className="text-center">
            <p className="text-sm text-muted-foreground mb-2">
              Want more recipe options?
            </p>
            <Button variant="outline" className="border-accent text-accent hover:bg-accent/10">
              View Recipes with Missing Ingredients
            </Button>
          </div>
        </Card>
      </div>
    </div>
  );
};

export default Scan;
