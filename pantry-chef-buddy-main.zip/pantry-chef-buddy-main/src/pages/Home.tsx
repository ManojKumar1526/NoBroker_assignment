import { ScanLine, BookOpen, ShoppingCart, Sparkles, ChefHat, Clock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { useNavigate } from "react-router-dom";
import RecipeCard from "@/components/RecipeCard";

const Home = () => {
  const navigate = useNavigate();

  const quickActions = [
    {
      icon: ScanLine,
      label: "Scan Ingredients",
      description: "See what you can make",
      color: "bg-primary",
      path: "/scan",
    },
    {
      icon: BookOpen,
      label: "Browse Recipes",
      description: "Explore your library",
      color: "bg-accent",
      path: "/recipes",
    },
    {
      icon: ShoppingCart,
      label: "Grocery List",
      description: "Never forget items",
      color: "bg-success",
      path: "/grocery",
    },
  ];

  const featuredRecipes = [
    {
      id: "1",
      title: "Classic Pasta Carbonara",
      image: "https://images.unsplash.com/photo-1612874742237-6526221588e3?w=800&q=80",
      time: "25 min",
      servings: 4,
      difficulty: "Easy" as const,
      tags: ["Italian", "Pasta"],
      matchPercentage: 85,
    },
    {
      id: "2",
      title: "Thai Green Curry",
      image: "https://images.unsplash.com/photo-1455619452474-d2be8b1e70cd?w=800&q=80",
      time: "40 min",
      servings: 6,
      difficulty: "Medium" as const,
      tags: ["Thai", "Spicy"],
      matchPercentage: 70,
    },
  ];

  return (
    <div className="min-h-screen pb-20 bg-gradient-warm">
      {/* Header */}
      <div className="gradient-hero text-white p-6 pb-8 rounded-b-3xl shadow-lg">
        <div className="max-w-md mx-auto">
          <div className="flex items-center gap-2 mb-2">
            <ChefHat className="h-8 w-8" />
            <h1 className="font-serif text-3xl font-bold">FreshPlate</h1>
          </div>
          <p className="text-white/90 text-lg">What are we cooking today?</p>
        </div>
      </div>

      <div className="max-w-md mx-auto px-4 -mt-4">
        {/* Quick Actions */}
        <Card className="p-4 mb-6 shadow-soft">
          <div className="space-y-3">
            {quickActions.map((action) => (
              <Button
                key={action.path}
                variant="ghost"
                className="w-full justify-start h-auto py-4 px-4 hover:bg-secondary"
                onClick={() => navigate(action.path)}
              >
                <div className={`${action.color} text-white p-3 rounded-xl mr-4`}>
                  <action.icon className="h-6 w-6" />
                </div>
                <div className="text-left flex-1">
                  <div className="font-semibold text-foreground">{action.label}</div>
                  <div className="text-sm text-muted-foreground">{action.description}</div>
                </div>
              </Button>
            ))}
          </div>
        </Card>

        {/* Smart Suggestions Section */}
        <div className="mb-6">
          <div className="flex items-center gap-2 mb-4">
            <Sparkles className="h-5 w-5 text-accent" />
            <h2 className="font-serif text-2xl font-bold">Smart Suggestions</h2>
          </div>
          <p className="text-muted-foreground mb-4">
            Based on ingredients you have at home
          </p>
          <div className="space-y-4">
            {featuredRecipes.map((recipe) => (
              <RecipeCard
                key={recipe.id}
                {...recipe}
                onClick={() => navigate(`/recipe/${recipe.id}`)}
              />
            ))}
          </div>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-3 gap-3 mb-6">
          <Card className="p-4 text-center">
            <div className="text-2xl font-bold text-primary">24</div>
            <div className="text-xs text-muted-foreground">Recipes Saved</div>
          </Card>
          <Card className="p-4 text-center">
            <div className="text-2xl font-bold text-accent">12</div>
            <div className="text-xs text-muted-foreground">Dishes Cooked</div>
          </Card>
          <Card className="p-4 text-center">
            <div className="flex items-center justify-center gap-1">
              <Clock className="h-4 w-4 text-success" />
              <div className="text-2xl font-bold text-success">5h</div>
            </div>
            <div className="text-xs text-muted-foreground">Time Saved</div>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default Home;
