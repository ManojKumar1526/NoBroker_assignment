import { useState } from "react";
import { Plus, Share2, Trash2, ShoppingCart, Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";

interface GroceryItem {
  id: string;
  name: string;
  quantity: string;
  category: string;
  checked: boolean;
}

const Grocery = () => {
  const [newItem, setNewItem] = useState("");
  const [items, setItems] = useState<GroceryItem[]>([
    { id: "1", name: "Tomatoes", quantity: "500g", category: "Produce", checked: false },
    { id: "2", name: "Pasta", quantity: "400g", category: "Pantry", checked: false },
    { id: "3", name: "Parmesan cheese", quantity: "100g", category: "Dairy", checked: false },
    { id: "4", name: "Eggs", quantity: "6", category: "Dairy", checked: true },
    { id: "5", name: "Olive oil", quantity: "1 bottle", category: "Pantry", checked: false },
    { id: "6", name: "Garlic", quantity: "1 bulb", category: "Produce", checked: false },
  ]);

  const categories = [...new Set(items.map(item => item.category))];
  const uncheckedCount = items.filter(item => !item.checked).length;

  const handleAddItem = () => {
    if (newItem.trim()) {
      const newGroceryItem: GroceryItem = {
        id: Date.now().toString(),
        name: newItem,
        quantity: "1",
        category: "Other",
        checked: false,
      };
      setItems([...items, newGroceryItem]);
      setNewItem("");
      toast.success("Item added to list");
    }
  };

  const handleToggleItem = (id: string) => {
    setItems(items.map(item =>
      item.id === id ? { ...item, checked: !item.checked } : item
    ));
  };

  const handleDeleteItem = (id: string) => {
    setItems(items.filter(item => item.id !== id));
    toast.success("Item removed");
  };

  const handleShare = () => {
    toast.success("Sharing list...");
  };

  const handleClearChecked = () => {
    setItems(items.filter(item => !item.checked));
    toast.success("Checked items cleared");
  };

  return (
    <div className="min-h-screen pb-20 bg-gradient-warm">
      {/* Header */}
      <div className="gradient-hero text-white p-6 pb-8">
        <div className="max-w-md mx-auto">
          <div className="flex items-center gap-2 mb-2">
            <ShoppingCart className="h-8 w-8" />
            <h1 className="font-serif text-3xl font-bold">Grocery List</h1>
          </div>
          <p className="text-white/90">
            {uncheckedCount} {uncheckedCount === 1 ? "item" : "items"} remaining
          </p>
        </div>
      </div>

      <div className="max-w-md mx-auto px-4 -mt-4">
        {/* Add Item */}
        <Card className="p-4 mb-6 shadow-soft">
          <div className="flex gap-2">
            <Input
              placeholder="Add item to list..."
              value={newItem}
              onChange={(e) => setNewItem(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleAddItem()}
              className="flex-1"
            />
            <Button onClick={handleAddItem} className="bg-primary">
              <Plus className="h-5 w-5" />
            </Button>
          </div>
        </Card>

        {/* Quick Actions */}
        <div className="flex gap-2 mb-6">
          <Button variant="outline" className="flex-1" onClick={handleShare}>
            <Share2 className="h-4 w-4 mr-2" />
            Share List
          </Button>
          <Button
            variant="outline"
            className="flex-1"
            onClick={handleClearChecked}
            disabled={!items.some(item => item.checked)}
          >
            <Trash2 className="h-4 w-4 mr-2" />
            Clear Checked
          </Button>
        </div>

        {/* Items by Category */}
        {categories.map((category) => {
          const categoryItems = items.filter(item => item.category === category);
          if (categoryItems.length === 0) return null;

          return (
            <Card key={category} className="p-4 mb-4 shadow-soft">
              <div className="flex items-center justify-between mb-3">
                <h3 className="font-semibold text-lg">{category}</h3>
                <Badge variant="secondary">{categoryItems.length}</Badge>
              </div>
              <div className="space-y-2">
                {categoryItems.map((item) => (
                  <div
                    key={item.id}
                    className="flex items-center gap-3 p-3 rounded-lg hover:bg-secondary/50 transition-colors group"
                  >
                    <button
                      onClick={() => handleToggleItem(item.id)}
                      className={`w-6 h-6 border-2 rounded flex items-center justify-center flex-shrink-0 ${
                        item.checked ? "bg-success border-success" : "border-border"
                      }`}
                    >
                      {item.checked && <Check className="h-4 w-4 text-white" />}
                    </button>
                    <div className="flex-1 min-w-0">
                      <div className={`font-medium ${item.checked ? "line-through text-muted-foreground" : ""}`}>
                        {item.name}
                      </div>
                      <div className="text-sm text-muted-foreground">{item.quantity}</div>
                    </div>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="opacity-0 group-hover:opacity-100 transition-opacity"
                      onClick={() => handleDeleteItem(item.id)}
                    >
                      <Trash2 className="h-4 w-4 text-destructive" />
                    </Button>
                  </div>
                ))}
              </div>
            </Card>
          );
        })}

        {/* Empty State */}
        {items.length === 0 && (
          <Card className="p-12 text-center">
            <ShoppingCart className="h-16 w-16 mx-auto mb-4 text-muted-foreground" />
            <h3 className="font-serif text-xl font-bold mb-2">Your list is empty</h3>
            <p className="text-muted-foreground mb-4">
              Add items manually or select recipes to auto-generate your list
            </p>
            <Button>Browse Recipes</Button>
          </Card>
        )}
      </div>
    </div>
  );
};

export default Grocery;
