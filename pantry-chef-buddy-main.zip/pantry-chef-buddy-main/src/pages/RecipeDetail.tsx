import { useState } from "react";
import { ArrowLeft, Clock, Users, Heart, Share2, Play, Plus, Check, Timer, Bell, ChefHat } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useNavigate, useParams } from "react-router-dom";
import { Progress } from "@/components/ui/progress";
import { TimerPanel } from "@/components/TimerPanel";
import { FloatingTimerButton } from "@/components/FloatingTimerButton";
import { TimerData } from "@/components/Timer";
import { useToast } from "@/hooks/use-toast";

const RecipeDetail = () => {
  const navigate = useNavigate();
  const { id } = useParams();
  const { toast } = useToast();
  const [isFavorited, setIsFavorited] = useState(false);
  const [isCooking, setIsCooking] = useState(false);
  const [currentStep, setCurrentStep] = useState(0);
  const [checkedIngredients, setCheckedIngredients] = useState<number[]>([]);
  const [activeTimers, setActiveTimers] = useState<TimerData[]>([]);
  const [isTimerPanelOpen, setIsTimerPanelOpen] = useState(false);

  const recipe = {
    title: "Classic Pasta Carbonara",
    image: "https://images.unsplash.com/photo-1612874742237-6526221588e3?w=800&q=80",
    time: "25 min",
    servings: 4,
    difficulty: "Easy",
    description: "A classic Italian pasta dish with eggs, cheese, pancetta, and black pepper. Simple yet incredibly delicious.",
    ingredients: [
      { name: "Spaghetti", amount: "400g" },
      { name: "Pancetta", amount: "200g, diced" },
      { name: "Eggs", amount: "4 large" },
      { name: "Parmesan cheese", amount: "100g, grated" },
      { name: "Black pepper", amount: "To taste" },
      { name: "Salt", amount: "For pasta water" },
    ],
    steps: [
      {
        number: 1,
        instruction: "Bring a large pot of salted water to boil. Add spaghetti and cook according to package directions.",
        duration: "10 min",
      },
      {
        number: 2,
        instruction: "While pasta cooks, crisp the pancetta in a large skillet over medium heat.",
        duration: "5 min",
      },
      {
        number: 3,
        instruction: "Whisk together eggs and grated Parmesan in a bowl. Season generously with black pepper.",
        duration: "2 min",
      },
      {
        number: 4,
        instruction: "Reserve 1 cup pasta water, then drain pasta. Add hot pasta to the skillet with pancetta.",
        duration: "1 min",
      },
      {
        number: 5,
        instruction: "Remove from heat. Pour egg mixture over pasta, tossing quickly. Add pasta water to create a creamy sauce.",
        duration: "3 min",
      },
      {
        number: 6,
        instruction: "Serve immediately with extra Parmesan and black pepper. Enjoy!",
        duration: "1 min",
      },
    ],
    nutrition: {
      calories: "520",
      protein: "28g",
      carbs: "52g",
      fat: "22g",
    },
    tags: ["Italian", "Pasta", "Quick Dinner"],
  };

  const toggleIngredient = (index: number) => {
    setCheckedIngredients(prev =>
      prev.includes(index) ? prev.filter(i => i !== index) : [...prev, index]
    );
  };

  const parseDuration = (durationStr: string): number => {
    const match = durationStr.match(/(\d+)/);
    return match ? parseInt(match[0]) * 60 : 300; // default 5 minutes
  };

  const addTimer = (step: typeof recipe.steps[0]) => {
    const newTimer: TimerData = {
      id: `timer-${Date.now()}`,
      label: step.instruction.slice(0, 40) + (step.instruction.length > 40 ? "..." : ""),
      duration: parseDuration(step.duration),
      stepNumber: step.number,
    };
    setActiveTimers(prev => [...prev, newTimer]);
    toast({
      title: "Timer Started",
      description: `${step.duration} timer for step ${step.number}`,
    });
  };

  const handleTimerComplete = (id: string) => {
    const timer = activeTimers.find(t => t.id === id);
    if (timer) {
      toast({
        title: "⏰ Timer Complete!",
        description: timer.label,
        duration: 5000,
      });
      // Vibration if available
      if (navigator.vibrate) {
        navigator.vibrate([200, 100, 200]);
      }
    }
  };

  const handleTimerDelete = (id: string) => {
    setActiveTimers(prev => prev.filter(t => t.id !== id));
  };

  const progress = isCooking ? ((currentStep + 1) / recipe.steps.length) * 100 : 0;

  return (
    <div className="min-h-screen pb-20 bg-gradient-warm">
      {/* Hero Image */}
      <div className="relative">
        <img
          src={recipe.image}
          alt={recipe.title}
          className="w-full h-64 object-cover"
        />
        <Button
          variant="ghost"
          size="icon"
          className="absolute top-4 left-4 bg-white/90 hover:bg-white"
          onClick={() => navigate(-1)}
        >
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <div className="absolute top-4 right-4 flex gap-2">
          <Button
            variant="ghost"
            size="icon"
            className={`${isFavorited ? "bg-destructive text-white" : "bg-white/90 hover:bg-white"}`}
            onClick={() => setIsFavorited(!isFavorited)}
          >
            <Heart className={`h-5 w-5 ${isFavorited ? "fill-current" : ""}`} />
          </Button>
          <Button variant="ghost" size="icon" className="bg-white/90 hover:bg-white">
            <Share2 className="h-5 w-5" />
          </Button>
        </div>
      </div>

      <div className="max-w-md mx-auto px-4 -mt-6">
        {/* Title Card */}
        <Card className="p-6 mb-4 shadow-soft">
          <h1 className="font-serif text-3xl font-bold mb-3">{recipe.title}</h1>
          <p className="text-muted-foreground mb-4">{recipe.description}</p>

          <div className="flex items-center gap-4 mb-4">
            <div className="flex items-center gap-2 text-sm">
              <Clock className="h-4 w-4 text-primary" />
              <span>{recipe.time}</span>
            </div>
            <div className="flex items-center gap-2 text-sm">
              <Users className="h-4 w-4 text-primary" />
              <span>{recipe.servings} servings</span>
            </div>
            <Badge className="bg-success/10 text-success">{recipe.difficulty}</Badge>
          </div>

          <div className="flex flex-wrap gap-2 mb-4">
            {recipe.tags.map((tag) => (
              <Badge key={tag} variant="secondary">
                {tag}
              </Badge>
            ))}
          </div>

          {!isCooking ? (
            <div className="flex gap-2">
              <Button className="flex-1 gradient-hero text-white" onClick={() => setIsCooking(true)}>
                <Play className="h-4 w-4 mr-2" />
                Start Cooking
              </Button>
              <Button variant="outline" onClick={() => navigate("/grocery")}>
                <Plus className="h-4 w-4 mr-2" />
                Add to List
              </Button>
            </div>
          ) : (
            <div>
              <div className="mb-2 flex items-center justify-between text-sm">
                <span className="font-medium">Step {currentStep + 1} of {recipe.steps.length}</span>
                <span className="text-muted-foreground">{Math.round(progress)}% Complete</span>
              </div>
              <Progress value={progress} className="mb-4" />
            </div>
          )}
        </Card>

        {/* Cooking Mode */}
        {isCooking && (
          <Card className="p-6 mb-4 shadow-elegant border-2 border-primary animate-fade-in bg-gradient-to-br from-primary/5 to-accent/5">
            <div className="flex items-start gap-3 mb-4">
              <div className="flex-shrink-0 w-10 h-10 rounded-full bg-primary text-white flex items-center justify-center font-bold shadow-soft">
                {currentStep + 1}
              </div>
              <div className="flex-1">
                <Badge className="mb-2 bg-primary/10 text-primary">
                  Step {currentStep + 1} of {recipe.steps.length}
                </Badge>
                <p className="text-lg font-medium leading-relaxed mb-3">
                  {recipe.steps[currentStep].instruction}
                </p>
                
                {/* Timer suggestion with enhanced UI */}
                <div className="flex flex-wrap gap-2 mb-3">
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="border-warning/50 bg-warning/5 text-warning hover:bg-warning/10 hover:border-warning shadow-sm"
                    onClick={() => addTimer(recipe.steps[currentStep])}
                  >
                    <Timer className="h-4 w-4 mr-2" />
                    Set Timer ({recipe.steps[currentStep].duration})
                  </Button>
                  
                  {activeTimers.length > 0 && (
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={() => setIsTimerPanelOpen(true)}
                      className="border-primary/30 bg-primary/5 hover:bg-primary/10"
                    >
                      <Bell className="h-4 w-4 mr-2" />
                      View {activeTimers.length} Active Timer{activeTimers.length > 1 ? 's' : ''}
                    </Button>
                  )}
                </div>

                {/* Quick tips */}
                <div className="flex items-center gap-2 text-sm text-muted-foreground bg-muted/50 p-2 rounded-lg">
                  <ChefHat className="h-4 w-4" />
                  <span>Pro tip: Set your timer before starting this step</span>
                </div>
              </div>
            </div>
            
            <div className="flex gap-2">
              {currentStep > 0 && (
                <Button 
                  variant="outline" 
                  onClick={() => setCurrentStep(currentStep - 1)}
                  className="hover-scale"
                >
                  Previous
                </Button>
              )}
              {currentStep < recipe.steps.length - 1 ? (
                <Button 
                  className="flex-1 gradient-hero text-white hover-scale shadow-soft" 
                  onClick={() => setCurrentStep(currentStep + 1)}
                >
                  Next Step
                </Button>
              ) : (
                <Button 
                  className="flex-1 gradient-accent text-white hover-scale shadow-elegant" 
                  onClick={() => {
                    setIsCooking(false);
                    toast({
                      title: "🎉 Recipe Complete!",
                      description: "Great job! Enjoy your meal.",
                    });
                  }}
                >
                  Complete Recipe! 🎉
                </Button>
              )}
            </div>
          </Card>
        )}

        {/* Ingredients */}
        <Card className="p-6 mb-4 shadow-soft">
          <h2 className="font-serif text-2xl font-bold mb-4">Ingredients</h2>
          <div className="space-y-3">
            {recipe.ingredients.map((ingredient, index) => (
              <div
                key={index}
                className="flex items-center gap-3 p-2 rounded-lg hover:bg-secondary cursor-pointer"
                onClick={() => toggleIngredient(index)}
              >
                <div className={`w-5 h-5 border-2 rounded flex items-center justify-center ${
                  checkedIngredients.includes(index) ? "bg-primary border-primary" : "border-border"
                }`}>
                  {checkedIngredients.includes(index) && (
                    <Check className="h-3 w-3 text-white" />
                  )}
                </div>
                <span className={checkedIngredients.includes(index) ? "line-through text-muted-foreground" : ""}>
                  {ingredient.amount} {ingredient.name}
                </span>
              </div>
            ))}
          </div>
        </Card>

        {/* Instructions */}
        {!isCooking && (
          <Card className="p-6 mb-4 shadow-soft">
            <h2 className="font-serif text-2xl font-bold mb-4">Instructions</h2>
            <div className="space-y-4">
              {recipe.steps.map((step) => (
                <div 
                  key={step.number} 
                  className="group flex gap-4 p-3 rounded-lg hover:bg-secondary/50 transition-colors"
                >
                  <div className="flex-shrink-0 w-8 h-8 rounded-full bg-primary text-white flex items-center justify-center font-semibold shadow-sm">
                    {step.number}
                  </div>
                  <div className="flex-1">
                    <p className="mb-2 leading-relaxed">{step.instruction}</p>
                    <div className="flex items-center gap-3">
                      <div className="flex items-center gap-1 text-sm text-muted-foreground">
                        <Clock className="h-3 w-3" />
                        <span>{step.duration}</span>
                      </div>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="h-7 px-2 opacity-0 group-hover:opacity-100 transition-opacity text-warning hover:text-warning hover:bg-warning/10"
                        onClick={() => addTimer(step)}
                      >
                        <Timer className="h-3 w-3 mr-1" />
                        Quick Timer
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </Card>
        )}

        {/* Nutrition */}
        <Card className="p-6 shadow-soft">
          <h2 className="font-serif text-2xl font-bold mb-4">Nutrition Per Serving</h2>
          <div className="grid grid-cols-2 gap-4">
            {Object.entries(recipe.nutrition).map(([key, value]) => (
              <div key={key} className="text-center p-3 bg-secondary rounded-lg">
                <div className="text-2xl font-bold text-primary">{value}</div>
                <div className="text-sm text-muted-foreground capitalize">{key}</div>
              </div>
            ))}
          </div>
        </Card>
      </div>

      {/* Floating Timer Button */}
      <FloatingTimerButton 
        count={activeTimers.length} 
        onClick={() => setIsTimerPanelOpen(true)} 
      />

      {/* Timer Panel */}
      <TimerPanel
        timers={activeTimers}
        isOpen={isTimerPanelOpen}
        onClose={() => setIsTimerPanelOpen(false)}
        onTimerComplete={handleTimerComplete}
        onTimerDelete={handleTimerDelete}
      />
    </div>
  );
};

export default RecipeDetail;
