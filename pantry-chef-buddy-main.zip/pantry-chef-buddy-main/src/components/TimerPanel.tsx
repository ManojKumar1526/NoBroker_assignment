import { Timer as TimerIcon, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Timer, TimerData } from "./Timer";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";

interface TimerPanelProps {
  timers: TimerData[];
  isOpen: boolean;
  onClose: () => void;
  onTimerComplete: (id: string) => void;
  onTimerDelete: (id: string) => void;
}

export const TimerPanel = ({
  timers,
  isOpen,
  onClose,
  onTimerComplete,
  onTimerDelete,
}: TimerPanelProps) => {
  return (
    <Sheet open={isOpen} onOpenChange={onClose}>
      <SheetContent side="bottom" className="h-[80vh] rounded-t-3xl">
        <SheetHeader>
          <SheetTitle className="flex items-center gap-2">
            <TimerIcon className="h-5 w-5 text-primary" />
            Active Timers ({timers.length})
          </SheetTitle>
        </SheetHeader>
        
        <div className="mt-6 space-y-4 overflow-y-auto h-[calc(80vh-80px)] pb-6">
          {timers.length === 0 ? (
            <div className="text-center py-12">
              <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-muted mb-4">
                <TimerIcon className="h-8 w-8 text-muted-foreground" />
              </div>
              <p className="text-muted-foreground">No active timers</p>
              <p className="text-sm text-muted-foreground mt-1">
                Set timers from recipe steps
              </p>
            </div>
          ) : (
            timers.map((timer) => (
              <Timer
                key={timer.id}
                timer={timer}
                onComplete={onTimerComplete}
                onDelete={onTimerDelete}
              />
            ))
          )}
        </div>
      </SheetContent>
    </Sheet>
  );
};
