import { useState, useEffect } from "react";
import { Timer as TimerIcon, Pause, Play, X, RotateCcw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";

export interface TimerData {
  id: string;
  label: string;
  duration: number; // in seconds
  stepNumber?: number;
}

interface TimerProps {
  timer: TimerData;
  onComplete: (id: string) => void;
  onDelete: (id: string) => void;
  compact?: boolean;
}

export const Timer = ({ timer, onComplete, onDelete, compact = false }: TimerProps) => {
  const [timeLeft, setTimeLeft] = useState(timer.duration);
  const [isRunning, setIsRunning] = useState(true);
  const [isCompleted, setIsCompleted] = useState(false);

  useEffect(() => {
    if (!isRunning || timeLeft <= 0) return;

    const interval = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          setIsRunning(false);
          setIsCompleted(true);
          onComplete(timer.id);
          // Play completion sound
          const audio = new Audio('data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACBhYqFbF1fdJivrJBhNjVgodDbq2EcBj+a2/LDciUFLIHO8tiJNwgZaLvt559NEAxQp+PwtmMcBjiR1/LMeSwFJHfH8N2QQAoUXrTp66hVFApGn+DyvmwhBTGH0fPTgjMGHm7A7+OZRA0PVqvn77BZFgpDm93xwHMkBSh+zPLaizsIGGS57OihUBELTKXh8bllHAU2jtXywn0pBSV7yvDdljwKE1y16+mjUxENS6Lf8rppHgU0iNPzwoU1Bx1qvu7mnEYODlOq5O+zXRYLQ5jb8cJ0JAUpe8rx3I0+CRZiturqpVMRC0mi4PG9aCEFM4nU88GHNwcaZ7zs56lQEgxLoeHyvGYdBTSJ1PLCiTYHHGi+7OaaRg8NUqjk7rVgGAU6j9jwx4s6ByF3wvDgpEsTC02k4fC8cScGLIfU8ciNPgsXaL7t6K1ZFgpFnN/yu3AfBi+G0vPPgDQFJnrJ8N+TQgoPW67n7bJdGAc8ltT0xY02Bx9wwO/mnUsSDU2k4fG9bCUGK4fS8s2NPwoWZ73s6KVXFQ1MouHxvGgeBS6H0/LDhzYGHGa97OmjTxENTKPh8bxnHgU1idPywoc1BxtmvOzpokwRDEqi4PG9Zh4FNInT8sOHNQccZrzt6aFNEQxKouHxvWYeBTOI0/LDhzYGHGa77OmhTREMSaLh8bxmHgU0iNPyw4c1Bhxmu+zpok0RDEmh4fG8Zh4FNIjT8sKHNQYbZrzt6aJNEQxJouHxvGYeBTOI0/LDhzUGHGa87OmiTREMSaLh8bxmHgUziNPyw4c1Bhxmu+3pokwRDEmi4fG8Zh4FM4jT8sOHNQYcZrzt6aJNEQxJouHxvGYeBTOI0/LDhzUGHGa87OmiTBEMSaLh8bxmHgUziNPyw4c1Bhxmu+3pokwRDEmi4fG8Zh4FM4jS8sOHNQYcZrzt6aJNEQxJouHxvGYeBTOI0/LDhzUGHGa87OmiTBEMSaLh8bxmHgUziNPyw4c1Bhxmu+3pokwRDEmi4fG8Zh4FM4jT8sOHNQYcZrzt6aJNEQxJouHxvGYeBTOI0/LDhzUGHGa87OmiTBEMSaLh8bxmHgUziNPyw4c1Bhxmu+3pokwRDEmi4fG8Zh4FM4jT8sOHNQYcZrzt6aJNEQxJouHxvGYeBTOI0/LDhzUGHGa87OmiTBEMSaLh8bxmHgU');
          audio.play().catch(() => {});
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [isRunning, timeLeft, timer.id, onComplete]);

  const togglePause = () => setIsRunning(!isRunning);
  
  const reset = () => {
    setTimeLeft(timer.duration);
    setIsRunning(false);
    setIsCompleted(false);
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const progress = ((timer.duration - timeLeft) / timer.duration) * 100;

  if (compact) {
    return (
      <div className={`flex items-center gap-2 p-2 rounded-lg border ${
        isCompleted ? 'bg-success/10 border-success animate-pulse' : 
        isRunning ? 'bg-primary/5 border-primary/20' : 'bg-muted border-border'
      }`}>
        <div className="flex-1">
          <div className="flex items-center gap-2 mb-1">
            {timer.stepNumber && (
              <span className="text-xs font-medium text-muted-foreground">
                Step {timer.stepNumber}
              </span>
            )}
            <span className="text-sm font-medium truncate">{timer.label}</span>
          </div>
          <div className="flex items-center gap-2">
            <span className={`text-lg font-bold tabular-nums ${
              isCompleted ? 'text-success' : 
              timeLeft <= 10 ? 'text-warning animate-pulse' : 'text-foreground'
            }`}>
              {formatTime(timeLeft)}
            </span>
            <Progress value={progress} className="h-1 flex-1" />
          </div>
        </div>
        <div className="flex gap-1">
          <Button
            size="icon"
            variant="ghost"
            className="h-7 w-7"
            onClick={togglePause}
          >
            {isRunning ? <Pause className="h-3 w-3" /> : <Play className="h-3 w-3" />}
          </Button>
          <Button
            size="icon"
            variant="ghost"
            className="h-7 w-7"
            onClick={() => onDelete(timer.id)}
          >
            <X className="h-3 w-3" />
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className={`relative overflow-hidden rounded-2xl p-6 shadow-elegant transition-all ${
      isCompleted ? 'bg-gradient-to-br from-success/20 to-success/5 border-2 border-success animate-scale-in' : 
      isRunning ? 'bg-card border border-primary/20' : 'bg-card border border-border'
    }`}>
      {/* Circular progress background */}
      <div className="absolute inset-0 opacity-5">
        <svg className="w-full h-full" viewBox="0 0 100 100">
          <circle
            cx="50"
            cy="50"
            r="45"
            fill="none"
            stroke="currentColor"
            strokeWidth="10"
            strokeDasharray={`${progress * 2.83} 283`}
            transform="rotate(-90 50 50)"
            className="text-primary transition-all duration-1000"
          />
        </svg>
      </div>

      <div className="relative">
        <div className="flex items-start justify-between mb-4">
          <div className="flex-1">
            {timer.stepNumber && (
              <div className="inline-flex items-center gap-1 px-2 py-1 rounded-full bg-primary/10 text-primary text-xs font-medium mb-2">
                <TimerIcon className="h-3 w-3" />
                Step {timer.stepNumber}
              </div>
            )}
            <h3 className="text-lg font-semibold">{timer.label}</h3>
          </div>
          <Button
            size="icon"
            variant="ghost"
            className="h-8 w-8 hover:bg-destructive/10 hover:text-destructive"
            onClick={() => onDelete(timer.id)}
          >
            <X className="h-4 w-4" />
          </Button>
        </div>

        <div className="text-center mb-6">
          <div className={`text-6xl font-bold tabular-nums transition-colors ${
            isCompleted ? 'text-success' : 
            timeLeft <= 10 ? 'text-warning' : 'text-foreground'
          }`}>
            {formatTime(timeLeft)}
          </div>
          {isCompleted && (
            <p className="text-success font-medium mt-2 animate-fade-in">
              ✓ Time's up!
            </p>
          )}
        </div>

        <Progress value={progress} className="h-2 mb-4" />

        <div className="flex gap-2">
          <Button
            variant="outline"
            className="flex-1"
            onClick={togglePause}
          >
            {isRunning ? (
              <>
                <Pause className="h-4 w-4 mr-2" />
                Pause
              </>
            ) : (
              <>
                <Play className="h-4 w-4 mr-2" />
                Resume
              </>
            )}
          </Button>
          <Button variant="outline" onClick={reset}>
            <RotateCcw className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </div>
  );
};
