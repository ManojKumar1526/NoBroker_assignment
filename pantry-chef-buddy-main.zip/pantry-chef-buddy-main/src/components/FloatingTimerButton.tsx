import { Timer as TimerIcon } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

interface FloatingTimerButtonProps {
  count: number;
  onClick: () => void;
}

export const FloatingTimerButton = ({ count, onClick }: FloatingTimerButtonProps) => {
  if (count === 0) return null;

  return (
    <Button
      onClick={onClick}
      className="fixed bottom-24 right-6 h-14 w-14 rounded-full shadow-elegant bg-primary hover:bg-primary/90 z-50 transition-all hover:scale-110 animate-scale-in"
      size="icon"
    >
      <div className="relative">
        <TimerIcon className="h-6 w-6 text-white" />
        {count > 0 && (
          <Badge className="absolute -top-2 -right-2 h-5 w-5 p-0 flex items-center justify-center bg-warning text-warning-foreground border-2 border-background animate-pulse">
            {count}
          </Badge>
        )}
      </div>
    </Button>
  );
};
