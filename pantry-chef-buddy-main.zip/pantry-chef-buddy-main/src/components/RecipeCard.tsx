import { Clock, Users, TrendingUp, Heart } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import { useState } from "react";

interface RecipeCardProps {
  id: string;
  title: string;
  image: string;
  time: string;
  servings: number;
  difficulty: "Easy" | "Medium" | "Hard";
  matchPercentage?: number;
  tags?: string[];
  onClick?: () => void;
}

const RecipeCard = ({
  title,
  image,
  time,
  servings,
  difficulty,
  matchPercentage,
  tags = [],
  onClick,
}: RecipeCardProps) => {
  const [isFavorited, setIsFavorited] = useState(false);

  const difficultyColors = {
    Easy: "bg-success/10 text-success",
    Medium: "bg-warning/10 text-warning",
    Hard: "bg-destructive/10 text-destructive",
  };

  return (
    <Card
      className="overflow-hidden cursor-pointer transition-all hover:shadow-lg hover:scale-[1.02] active:scale-[0.98]"
      onClick={onClick}
    >
      <div className="relative">
        <img
          src={image}
          alt={title}
          className="w-full h-48 object-cover"
        />
        {matchPercentage && (
          <Badge className="absolute top-3 left-3 bg-primary text-primary-foreground shadow-md">
            {matchPercentage}% Match
          </Badge>
        )}
        <button
          className={cn(
            "absolute top-3 right-3 p-2 rounded-full backdrop-blur-sm transition-all",
            isFavorited
              ? "bg-destructive/90 text-white"
              : "bg-white/90 text-foreground hover:bg-white"
          )}
          onClick={(e) => {
            e.stopPropagation();
            setIsFavorited(!isFavorited);
          }}
        >
          <Heart className={cn("h-5 w-5", isFavorited && "fill-current")} />
        </button>
      </div>

      <div className="p-4 space-y-3">
        <h3 className="font-serif text-lg font-bold line-clamp-2">{title}</h3>

        <div className="flex items-center gap-4 text-sm text-muted-foreground">
          <div className="flex items-center gap-1">
            <Clock className="h-4 w-4" />
            <span>{time}</span>
          </div>
          <div className="flex items-center gap-1">
            <Users className="h-4 w-4" />
            <span>{servings}</span>
          </div>
          <div className="flex items-center gap-1">
            <TrendingUp className="h-4 w-4" />
            <span>{difficulty}</span>
          </div>
        </div>

        {tags.length > 0 && (
          <div className="flex flex-wrap gap-2">
            {tags.map((tag) => (
              <Badge
                key={tag}
                variant="secondary"
                className="text-xs"
              >
                {tag}
              </Badge>
            ))}
          </div>
        )}

        <Badge
          className={cn("w-fit", difficultyColors[difficulty])}
          variant="secondary"
        >
          {difficulty}
        </Badge>
      </div>
    </Card>
  );
};

export default RecipeCard;
